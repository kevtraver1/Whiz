from flask import Flask, jsonify,render_template, request, redirect, Response, json

app = Flask(__name__)

@app.route("/", methods=['GET','POST'])
def home():
    if request.headers['Content-Type'] == 'text/plain':
        return "Text Message: " + request.data

    elif request.headers['Content-Type'] == 'application/json':
        return "JSON Message: " + json.dumps(request.json)

    elif request.headers['Content-Type'] == 'application/octet-stream':
        f = open('./binary', 'wb')
        f.write(request.data)
                f.close()
        return "Binary message written!"

    else:
        return "415 Unsupported Media Type ;)"
	#return jsonify({"Response":request.args.get("test")})


if __name__=="__main__":
	#app.debug = True
	app.run()
